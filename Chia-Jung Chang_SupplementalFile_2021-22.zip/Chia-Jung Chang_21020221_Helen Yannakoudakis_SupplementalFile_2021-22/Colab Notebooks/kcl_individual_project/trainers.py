import torch
from torch.autograd import Variable
from transformers import get_scheduler
import os
import comp_models as cm
import numpy as np

eps = 0.00001
lambda_reg = 0.05
update_frequency = int(20)

device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

def func(x):
    if x > 0.1:
        return 1. / x
    else:
        return x

def eig_decomp(omega):
    u, s, vh = torch.svd(omega)
    s = s.cpu().apply_(func).cuda()

    omega_t = torch.mm(u, torch.mm(torch.diag(s), torch.t(vh)))
    omega_t_trace = torch.trace(omega_t)

    if omega_t_trace > 3000.0:
        return Variable(omega_t / omega_t_trace * 3000.0)

    return Variable(omega_t)

def loss_fn(outputs, targets):
    return torch.nn.CrossEntropyLoss(ignore_index=-100)(outputs, targets)

def covariance_mat_update(weights, tensor1, tensor2):
    mat_d = weights.shape[0]
    temp = torch.mm(weights.reshape(mat_d, -1), torch.t(torch.matmul(tensor1, torch.matmul(weights, torch.t(tensor2))).reshape(mat_d, -1)))
    return temp + eps * torch.eye(temp.shape[0]).cuda()

def loss_reg(weights, tensor1, tensor2, tensor3):
    temp1 = torch.matmul(weights, torch.t(tensor3).cuda()).cuda()
    temp2 = torch.matmul(tensor2, temp1.cuda()).cuda()
    temp3 = torch.matmul(tensor1, temp2.cuda().permute(1,0,2)).permute(1,0,2)
    return torch.mm(weights.reshape(1, -1), temp3.cuda().reshape(-1, 1)).reshape(1)

def weights_cat_conll2003(W1_ini,W2_ini,W3_ini):
    W1_temp = W1_ini.clone()
    W2_temp = W2_ini.clone()
    W3_temp = W3_ini.clone()
    comb_shape_0 = W1_temp.shape[0] + W2_temp.shape[0] + W3_temp.shape[0]
    comb_shape_1 = W1_temp.shape[1]
    W1 = torch.cat([W1_temp, torch.zeros(W2_temp.shape[0] + W3_temp.shape[0], comb_shape_1).cuda()], dim=0)
    W2 = torch.cat([torch.zeros(W1_temp.shape[0], comb_shape_1).cuda(), W2_temp, torch.zeros(W3_temp.shape[0], comb_shape_1).cuda()], dim=0)
    W3 = torch.cat([torch.zeros(W1_temp.shape[0] + W2_temp.shape[0], comb_shape_1).cuda(), W3_temp], dim=0)
    weights_cat_t = [W1.reshape(1, comb_shape_0, comb_shape_1), W2.reshape(1, comb_shape_0, comb_shape_1), W3.reshape(1, comb_shape_0, comb_shape_1)]
    return torch.cat(weights_cat_t, dim=0).cuda()

def calculate_reg_conll2003(W1_ini,W2_ini,W3_ini,model):
    weights = weights_cat_conll2003(W1_ini,W2_ini,W3_ini)
    print(weights.shape)
    return loss_reg(weights, model.task_covariance, model.class_covariance, model.feature_covariance)

def weights_cat_conll2000(W1_ini,W2_ini):
    W1_temp = W1_ini.clone()
    W2_temp = W2_ini.clone()
    comb_shape_0 = W1_temp.shape[0] + W2_temp.shape[0]
    comb_shape_1 = W1_temp.shape[1]
    W1 = torch.cat([W1_temp, torch.zeros(W2_temp.shape[0], comb_shape_1).cuda()], dim=0)
    W2 = torch.cat([torch.zeros(W1_temp.shape[0], comb_shape_1).cuda(), W2_temp], dim=0)
    weights_cat_t = [W1.reshape(1, comb_shape_0, comb_shape_1), W2.reshape(1, comb_shape_0, comb_shape_1)]
    return torch.cat(weights_cat_t, dim=0).cuda()

def calculate_reg_conll2000(W1_ini,W2_ini,model):
    weights = weights_cat_conll2000(W1_ini,W2_ini)
    print(weights.shape)
    return loss_reg(weights, model.task_covariance, model.class_covariance, model.feature_covariance)

def weights_cat_both_pos(W1_ini,W2_ini):
    W1_temp = W1_ini.clone()
    W2_temp = W2_ini.clone()
    comb_shape_0 = W1_temp.shape[0]
    comb_shape_1 = W1_temp.shape[1]
    W1 = torch.cat(
    [
        W1_temp[1:19,:],
        W1_temp[20:25,:],
        W1_temp[26:47,:],
        W1_temp[0,:].reshape(1,comb_shape_1),
        W1_temp[19,:].reshape(1,comb_shape_1),
        W1_temp[25,:].reshape(1,comb_shape_1)
    ],
        dim=0
    )
    W2 = torch.cat([W2_temp, torch.zeros(3, comb_shape_1).cuda()], dim=0)
    weights_cat_t = [W1.reshape(1, comb_shape_0, comb_shape_1), W2.reshape(1, comb_shape_0, comb_shape_1)]
    return torch.cat(weights_cat_t, dim=0).cuda()

def calculate_reg_both_pos(W1_ini,W2_ini,model):
    weights = weights_cat_both_pos(W1_ini,W2_ini)
    print(weights.shape)
    return loss_reg(weights, model.task_covariance, model.class_covariance, model.feature_covariance)

def train_conll2003_MRN(EPOCHS, training_loader, validation_loader, model, optimizer, checkpoint_path):
    # average validation loss
    avg_valid_loss = np.Inf

    # create a linear learning rate scheduler
    learning_rate_scheduler = get_scheduler(
        "linear",
        optimizer=optimizer,
        num_warmup_steps=0,
        num_training_steps=EPOCHS * len(training_loader),
    )

    for epoch in range(1, EPOCHS + 1):
        train_loss = 0.0
        valid_loss = 0.0
        reg_loss = 0.0
        model.train()
        print(f"---------- Epoch {epoch}: Training Stage ----------")

        for idx, data in enumerate(training_loader):
            ids = data['input_ids'].to(device, dtype=torch.long)
            mask = data['attention_mask'].to(device, dtype=torch.long)
            pos = data['pos'].reshape(-1).type(torch.LongTensor).to(device)
            chunk = data['chunk'].reshape(-1).type(torch.LongTensor).to(device)
            ner = data['ner'].reshape(-1).type(torch.LongTensor).to(device)

            optimizer.zero_grad()
            outputs1, outputs2, outputs3, W1_ini, W2_ini, W3_ini = model(ids, mask)
            # print(outputs1.shape) --> (32,256,47)
            pred1 = outputs1.reshape(-1, 47).to(device, dtype=torch.float32)
            pred2 = outputs2.reshape(-1, 23).to(device, dtype=torch.float32)
            pred3 = outputs3.reshape(-1, 9).to(device, dtype=torch.float32)

            with torch.enable_grad():
                regularizer = calculate_reg_conll2003(W1_ini, W2_ini, W3_ini, model)
                loss = loss_fn(pred1, pos) / 3 + loss_fn(pred2, chunk) / 3 + loss_fn(pred3, ner) / 3 + lambda_reg * regularizer

                loss.requires_grad_(True)
                print(f"train_loss: {loss.item()}, reg_loss: {lambda_reg * regularizer.item()}")
                loss.backward()
                optimizer.step()
                learning_rate_scheduler.step()

                train_loss += loss.item()
                reg_loss += lambda_reg * regularizer.item()

            if idx % update_frequency == 0:
                weights = weights_cat_conll2003(W1_ini, W2_ini, W3_ini)

                temp_task_covariance = covariance_mat_update(weights.data, model.class_covariance.data, model.feature_covariance.data)
                temp_class_covariance = covariance_mat_update(weights.data.permute(1, 0, 2), model.task_covariance.data, model.feature_covariance.data)
                temp_feature_covariance = covariance_mat_update(weights.data.permute(2, 0, 1), model.task_covariance.data, model.class_covariance.data)

                model.task_covariance = eig_decomp(temp_task_covariance).cuda()
                model.class_covariance = eig_decomp(temp_class_covariance).cuda()
                model.feature_covariance = eig_decomp(temp_feature_covariance).cuda()

        print(f"---------- Epoch {epoch}: Training Stage End ----------")
        train_loss = train_loss / len(training_loader)
        reg_loss = reg_loss / len(training_loader)

        print(f"---------- Epoch {epoch}: Validation Stage ----------")

        model.eval()

        with torch.no_grad():
            for idx, data in enumerate(validation_loader):
                ids = data['input_ids'].to(device, dtype=torch.long)
                mask = data['attention_mask'].to(device, dtype=torch.long)
                pos = data['pos'].reshape(-1).type(torch.LongTensor).to(device)
                chunk = data['chunk'].reshape(-1).type(torch.LongTensor).to(device)
                ner = data['ner'].reshape(-1).type(torch.LongTensor).to(device)

                outputs1, outputs2, outputs3, W1_ini, W2_ini, W3_ini = model(ids, mask)
                pred1 = outputs1.reshape(-1, 47).to(device, dtype=torch.float32)
                pred2 = outputs2.reshape(-1, 23).to(device, dtype=torch.float32)
                pred3 = outputs3.reshape(-1, 9).to(device, dtype=torch.float32)

                regularizer = calculate_reg_conll2003(W1_ini, W2_ini, W3_ini, model)
                loss = loss_fn(pred1, pos) / 3 + loss_fn(pred2, chunk) / 3 + loss_fn(pred3, ner) / 3 + lambda_reg * regularizer
                print(f"valid_loss: {loss.item()}")

                valid_loss += loss.item()

            print(f"---------- Epoch {epoch}: Validation Stage End ----------")
            valid_loss = valid_loss / len(validation_loader)

            # Training and Validation losses
            print(f"Epoch: {epoch}, Training Loss: {train_loss}, Validation Loss: {valid_loss}")

            # checkpoint for saving
            checkpoint = {
                'epoch': epoch,
                'avg_valid_loss': valid_loss,
                'state_dict': model.state_dict(),
                'optimizer': optimizer.state_dict()
            }

            # save the checkpoint
            print("Saving the checkpoint...")
            cm.save_model(checkpoint, checkpoint_path)

            # see whether the validation loss drops or not
            if valid_loss <= avg_valid_loss:
                print(f"Validation loss decreases from {avg_valid_loss} to {valid_loss}")
                avg_valid_loss = valid_loss
            else:
                print(f"Validation loss increases from {avg_valid_loss} to {valid_loss}")
        print(f"---------- Epoch {epoch}: End ----------")

    return model

def train_conll2000_MRN(EPOCHS, training_loader, validation_loader, model, optimizer, checkpoint_path):
    # average validation loss
    avg_valid_loss = np.Inf

    # create a linear learning rate scheduler
    learning_rate_scheduler = get_scheduler(
        "linear",
        optimizer=optimizer,
        num_warmup_steps=0,
        num_training_steps=EPOCHS * len(training_loader),
    )
    for epoch in range(1, EPOCHS + 1):
        train_loss = 0.0
        valid_loss = 0.0
        reg_loss = 0.0

        model.train()
        print(f"---------- Epoch {epoch}: Training Stage ----------")

        for idx, data in enumerate(training_loader):
            ids = data['input_ids'].to(device, dtype=torch.long)
            mask = data['attention_mask'].to(device, dtype=torch.long)
            pos = data['pos'].reshape(-1).type(torch.LongTensor).to(device)
            chunk = data['chunk'].reshape(-1).type(torch.LongTensor).to(device)

            optimizer.zero_grad()
            outputs1, outputs2, W1_ini, W2_ini = model(ids, mask)

            pred1 = outputs1.reshape(-1, 44).to(device, dtype=torch.float32)
            pred2 = outputs2.reshape(-1, 23).to(device, dtype=torch.float32)

            with torch.enable_grad():
                regularizer = calculate_reg_conll2000(W1_ini, W2_ini, model)
                loss = loss_fn(pred1, pos) / 2 + loss_fn(pred2, chunk) / 2 + lambda_reg * regularizer

                loss.requires_grad_(True)
                print(f"train_loss: {loss.item()}, reg_loss: {lambda_reg * regularizer.item()}")
                loss.backward()
                optimizer.step()
                learning_rate_scheduler.step()

                train_loss += loss.item()
                reg_loss += lambda_reg * regularizer.item()

            if idx % update_frequency == 0:
                weights = weights_cat_conll2000(W1_ini, W2_ini)

                temp_task_covariance = covariance_mat_update(weights.data, model.class_covariance.data, model.feature_covariance.data)
                temp_class_covariance = covariance_mat_update(weights.data.permute(1, 0, 2), model.task_covariance.data, model.feature_covariance.data)
                temp_feature_covariance = covariance_mat_update(weights.data.permute(2, 0, 1), model.task_covariance.data, model.class_covariance.data)

                model.task_covariance = eig_decomp(temp_task_covariance).cuda()
                model.class_covariance = eig_decomp(temp_class_covariance).cuda()
                model.feature_covariance = eig_decomp(temp_feature_covariance).cuda()

        print(f"---------- Epoch {epoch}: Training Stage End ----------")
        train_loss = train_loss / len(training_loader)
        reg_loss = reg_loss / len(training_loader)

        checkpoint = {
            'epoch': epoch,
            'avg_valid_loss': train_loss,
            'state_dict': model.state_dict(),
            'optimizer': optimizer.state_dict()
        }
        cm.save_model(checkpoint, checkpoint_path)
        print(f"---------- Epoch {epoch}: End ----------")
        model.eval()
    return model

def train_conll2003_MTL(EPOCHS, training_loader, validation_loader, model, optimizer, checkpoint_path):
    # average validation loss
    avg_valid_loss = np.Inf

    # create a linear learning rate scheduler
    learning_rate_scheduler = get_scheduler(
        "linear",
        optimizer=optimizer,
        num_warmup_steps=0,
        num_training_steps=EPOCHS * len(training_loader),
    )

    for epoch in range(1, EPOCHS + 1):
        train_loss = 0.0
        valid_loss = 0.0
        model.train()
        print(f"---------- Epoch {epoch}: Training Stage ----------")

        for idx, data in enumerate(training_loader):
            ids = data['input_ids'].to(device, dtype=torch.long)
            mask = data['attention_mask'].to(device, dtype=torch.long)
            pos = data['pos'].reshape(-1).type(torch.LongTensor).to(device)
            chunk = data['chunk'].reshape(-1).type(torch.LongTensor).to(device)
            ner = data['ner'].reshape(-1).type(torch.LongTensor).to(device)

            optimizer.zero_grad()
            outputs1, outputs2, outputs3 = model(ids, mask)
            pred1 = outputs1.reshape(-1, 47).to(device, dtype=torch.float32)
            pred2 = outputs2.reshape(-1, 23).to(device, dtype=torch.float32)
            pred3 = outputs3.reshape(-1, 9).to(device, dtype=torch.float32)

            with torch.enable_grad():
                loss = loss_fn(pred1, pos) / 3 + loss_fn(pred2, chunk) / 3 + loss_fn(pred3, ner) / 3

                loss.requires_grad_(True)
                print(f"train_loss: {loss.item()}")
                loss.backward()
                optimizer.step()
                learning_rate_scheduler.step()

                train_loss += loss.item()

        print(f"---------- Epoch {epoch}: Training Stage End ----------")
        train_loss = train_loss / len(training_loader)

        print(f"---------- Epoch {epoch}: Validation Stage ----------")

        model.eval()

        with torch.no_grad():
            for idx, data in enumerate(validation_loader):
                ids = data['input_ids'].to(device, dtype=torch.long)
                mask = data['attention_mask'].to(device, dtype=torch.long)
                pos = data['pos'].reshape(-1).type(torch.LongTensor).to(device)
                chunk = data['chunk'].reshape(-1).type(torch.LongTensor).to(device)
                ner = data['ner'].reshape(-1).type(torch.LongTensor).to(device)

                outputs1, outputs2, outputs3 = model(ids, mask)
                pred1 = outputs1.reshape(-1, 47).to(device, dtype=torch.float32)
                pred2 = outputs2.reshape(-1, 23).to(device, dtype=torch.float32)
                pred3 = outputs3.reshape(-1, 9).to(device, dtype=torch.float32)

                loss = loss_fn(pred1, pos) / 3 + loss_fn(pred2, chunk) / 3 + loss_fn(pred3, ner) / 3
                print(f"valid_loss: {loss.item()}")

                valid_loss += loss.item()

            print(f"---------- Epoch {epoch}: Validation Stage End ----------")
            valid_loss = valid_loss / len(validation_loader)

            # Training and Validation losses
            print(f"Epoch: {epoch}, Training Loss: {train_loss}, Validation Loss: {valid_loss}")

            # checkpoint for saving
            checkpoint = {
                'epoch': epoch,
                'avg_valid_loss': valid_loss,
                'state_dict': model.state_dict(),
                'optimizer': optimizer.state_dict()
            }

            # save the checkpoint
            print("Saving the checkpoint...")
            cm.save_model(checkpoint, checkpoint_path)

            # see whether the validation loss drops or not
            if valid_loss <= avg_valid_loss:
                print(f"Validation loss decreases from {avg_valid_loss} to {valid_loss}")
                avg_valid_loss = valid_loss
            else:
                print(f"Validation loss increases from {avg_valid_loss} to {valid_loss}")
        print(f"---------- Epoch {epoch}: End ----------")

    return model

def train_conll2000_MTL(EPOCHS, training_loader, validation_loader, model, optimizer, checkpoint_path):
    # average validation loss
    avg_valid_loss = np.Inf

    # create a linear learning rate scheduler
    learning_rate_scheduler = get_scheduler(
        "linear",
        optimizer=optimizer,
        num_warmup_steps=0,
        num_training_steps=EPOCHS * len(training_loader),
    )
    for epoch in range(1, EPOCHS + 1):
        train_loss = 0.0
        valid_loss = 0.0

        model.train()
        print(f"---------- Epoch {epoch}: Training Stage ----------")

        for idx, data in enumerate(training_loader):
            ids = data['input_ids'].to(device, dtype=torch.long)
            mask = data['attention_mask'].to(device, dtype=torch.long)
            pos = data['pos'].reshape(-1).type(torch.LongTensor).to(device)
            chunk = data['chunk'].reshape(-1).type(torch.LongTensor).to(device)

            optimizer.zero_grad()
            outputs1, outputs2 = model(ids, mask)

            pred1 = outputs1.reshape(-1, 44).to(device, dtype=torch.float32)
            pred2 = outputs2.reshape(-1, 23).to(device, dtype=torch.float32)

            with torch.enable_grad():
                loss = loss_fn(pred1, pos) / 2 + loss_fn(pred2, chunk) / 2

                loss.requires_grad_(True)
                print(f"train_loss: {loss.item()}")
                loss.backward()
                optimizer.step()
                learning_rate_scheduler.step()

                train_loss += loss.item()

        print(f"---------- Epoch {epoch}: Training Stage End ----------")
        train_loss = train_loss / len(training_loader)

        checkpoint = {
            'epoch': epoch,
            'avg_valid_loss': train_loss,
            'state_dict': model.state_dict(),
            'optimizer': optimizer.state_dict()
        }
        cm.save_model(checkpoint, checkpoint_path)
        print(f"---------- Epoch {epoch}: End ----------")
        model.eval()
    return model

def train_STL(EPOCHS, training_loader, validation_loader, model, optimizer, checkpoint_path, num_labels, task):
    # average validation loss
    avg_valid_loss = np.Inf

    # create a linear learning rate scheduler
    learning_rate_scheduler = get_scheduler(
        "linear",
        optimizer=optimizer,
        num_warmup_steps=0,
        num_training_steps=EPOCHS * len(training_loader),
    )

    for epoch in range(1, EPOCHS + 1):
        train_loss = 0.0
        valid_loss = 0.0
        model.train()
        print(f"---------- Epoch {epoch}: Training Stage ----------")

        for idx, data in enumerate(training_loader):
            ids = data['input_ids'].to(device, dtype=torch.long)
            mask = data['attention_mask'].to(device, dtype=torch.long)
            TASK = data[f"{task}"].reshape(-1).type(torch.LongTensor).to(device)

            optimizer.zero_grad()

            out = model(ids, mask)
            pred = out.reshape(-1, num_labels).to(device, dtype=torch.float32)

            with torch.enable_grad():
                loss = loss_fn(pred, TASK)

                loss.requires_grad_(True)
                print(f"train_loss: {loss.item()}")
                loss.backward()
                optimizer.step()
                learning_rate_scheduler.step()
                train_loss += loss.item()

        print(f"---------- Epoch {epoch}: Training Stage End ----------")
        train_loss = train_loss / len(training_loader)

        model.eval()
        if len(validation_loader) == 0:
            print(f"Epoch: {epoch}, Training Loss: {train_loss}")
            checkpoint = {
                'epoch': epoch,
                'avg_valid_loss': train_loss,
                'state_dict': model.state_dict(),
                'optimizer': optimizer.state_dict()
            }
            cm.save_model(checkpoint, checkpoint_path)
            print(f"---------- Epoch {epoch}: End ----------")
            continue
        
        print(f"---------- Epoch {epoch}: Validation Stage ----------")

        with torch.no_grad():
            for idx, data in enumerate(validation_loader):
                ids = data['input_ids'].to(device, dtype=torch.long)
                mask = data['attention_mask'].to(device, dtype=torch.long)
                TASK = data[f"{task}"].reshape(-1).type(torch.LongTensor).to(device)

                out = model(ids, mask)
                pred = out.reshape(-1, num_labels).to(device, dtype=torch.float32)

                loss = loss_fn(pred, TASK)
                print(f"valid_loss: {loss.item()}")

                valid_loss += loss.item()

            print(f"---------- Epoch {epoch}: Validation Stage End ----------")
            valid_loss = valid_loss / len(validation_loader)

            # Training and Validation losses
            print(f"Epoch: {epoch}, Training Loss: {train_loss}, Validation Loss: {valid_loss}")

            # checkpoint for saving
            checkpoint = {
                'epoch': epoch,
                'avg_valid_loss': valid_loss,
                'state_dict': model.state_dict(),
                'optimizer': optimizer.state_dict()
            }

            # save the checkpoint
            print("Saving the checkpoint...")
            cm.save_model(checkpoint, checkpoint_path)

            # see whether the validation loss drops or not
            if valid_loss <= avg_valid_loss:
                print(f"Validation loss decreases from {avg_valid_loss} to {valid_loss}")
                avg_valid_loss = valid_loss
            else:
                print(f"Validation loss increases from {avg_valid_loss} to {valid_loss}")
        print(f"---------- Epoch {epoch}: End ----------")

    return model

def train_both_pos_MRN(EPOCHS, proportion, training_loader03, training_loader00, model, optimizer, checkpoint_path):
    # average validation loss
    avg_valid_loss = np.Inf

    # create a linear learning rate scheduler
    learning_rate_scheduler = get_scheduler(
        "linear",
        optimizer=optimizer,
        num_warmup_steps=0,
        num_training_steps=EPOCHS * proportion * ( len(training_loader03) + len(training_loader00) ),
    )
    for epoch in range(1, EPOCHS + 1):
        train_loss = 0.0
        valid_loss = 0.0
        reg_loss = 0.0

        model.train()
        print(f"---------- Epoch {epoch}: Training Stage ----------")

        for idx, data in enumerate(training_loader03):
            ids = data['input_ids'].to(device, dtype=torch.long)
            mask = data['attention_mask'].to(device, dtype=torch.long)
            pos = data['pos'].reshape(-1).type(torch.LongTensor).to(device)

            optimizer.zero_grad()
            outputs1, outputs2, W1_ini, W2_ini = model(ids, mask)

            pred1 = outputs1.reshape(-1, 47).to(device, dtype=torch.float32)

            with torch.enable_grad():
                regularizer = calculate_reg_both_pos(W1_ini, W2_ini, model)
                loss = loss_fn(pred1, pos) + lambda_reg * regularizer

                loss.requires_grad_(True)
                print(f"train_loss: {loss.item()}, reg_loss: {lambda_reg * regularizer.item()}")
                loss.backward()
                optimizer.step()
                learning_rate_scheduler.step()

                train_loss += loss.item()
                reg_loss += lambda_reg * regularizer.item()

            if idx % update_frequency == 0:
                weights = weights_cat_both_pos(W1_ini, W2_ini)

                temp_task_covariance = covariance_mat_update(weights.data, model.class_covariance.data, model.feature_covariance.data)
                temp_class_covariance = covariance_mat_update(weights.data.permute(1, 0, 2), model.task_covariance.data, model.feature_covariance.data)
                temp_feature_covariance = covariance_mat_update(weights.data.permute(2, 0, 1), model.task_covariance.data, model.class_covariance.data)

                model.task_covariance = eig_decomp(temp_task_covariance).cuda()
                model.class_covariance = eig_decomp(temp_class_covariance).cuda()
                model.feature_covariance = eig_decomp(temp_feature_covariance).cuda()
            if idx > (proportion * len(training_loader03)):
                break
        for idx, data in enumerate(training_loader00):
            ids = data['input_ids'].to(device, dtype=torch.long)
            mask = data['attention_mask'].to(device, dtype=torch.long)
            pos = data['pos'].reshape(-1).type(torch.LongTensor).to(device)

            optimizer.zero_grad()
            outputs1, outputs2, W1_ini, W2_ini = model(ids, mask)

            pred2 = outputs2.reshape(-1, 44).to(device, dtype=torch.float32)

            with torch.enable_grad():
                regularizer = calculate_reg_both_pos(W1_ini, W2_ini, model)
                loss = loss_fn(pred2, pos) + lambda_reg * regularizer

                loss.requires_grad_(True)
                print(f"train_loss: {loss.item()}, reg_loss: {lambda_reg * regularizer.item()}")
                loss.backward()
                optimizer.step()
                learning_rate_scheduler.step()

                train_loss += loss.item()
                reg_loss += lambda_reg * regularizer.item()

            if idx % update_frequency == 0:
                weights = weights_cat_both_pos(W1_ini, W2_ini)

                temp_task_covariance = covariance_mat_update(weights.data, model.class_covariance.data, model.feature_covariance.data)
                temp_class_covariance = covariance_mat_update(weights.data.permute(1, 0, 2), model.task_covariance.data, model.feature_covariance.data)
                temp_feature_covariance = covariance_mat_update(weights.data.permute(2, 0, 1), model.task_covariance.data, model.class_covariance.data)

                model.task_covariance = eig_decomp(temp_task_covariance).cuda()
                model.class_covariance = eig_decomp(temp_class_covariance).cuda()
                model.feature_covariance = eig_decomp(temp_feature_covariance).cuda()
            if idx > (proportion * len(training_loader00)):
                break

        print(f"---------- Epoch {epoch}: Training Stage End ----------")
        train_loss = train_loss / (proportion * ( len(training_loader03) + len(training_loader00) ))
        reg_loss = reg_loss / (proportion * ( len(training_loader03) + len(training_loader00) ))

        checkpoint = {
            'epoch': epoch,
            'avg_valid_loss': train_loss,
            'state_dict': model.state_dict(),
            'optimizer': optimizer.state_dict()
        }
        cm.save_model(checkpoint, checkpoint_path)
        print(f"---------- Epoch {epoch}: End ----------")
        model.eval()
    return model

def train_both_pos_MTL(EPOCHS, proportion, training_loader03, training_loader00, model, optimizer, checkpoint_path):
    # average validation loss
    avg_valid_loss = np.Inf

    # create a linear learning rate scheduler
    learning_rate_scheduler = get_scheduler(
        "linear",
        optimizer=optimizer,
        num_warmup_steps=0,
        num_training_steps=EPOCHS * proportion * ( len(training_loader03) + len(training_loader00) ),
    )
    for epoch in range(1, EPOCHS + 1):
        train_loss = 0.0
        valid_loss = 0.0

        model.train()
        print(f"---------- Epoch {epoch}: Training Stage ----------")

        for idx, data in enumerate(training_loader03):
            ids = data['input_ids'].to(device, dtype=torch.long)
            mask = data['attention_mask'].to(device, dtype=torch.long)
            pos = data['pos'].reshape(-1).type(torch.LongTensor).to(device)

            optimizer.zero_grad()
            outputs1, outputs2 = model(ids, mask)

            pred1 = outputs1.reshape(-1, 47).to(device, dtype=torch.float32)

            with torch.enable_grad():
                loss = loss_fn(pred1, pos)

                loss.requires_grad_(True)
                print(f"train_loss: {loss.item()}")
                loss.backward()
                optimizer.step()
                learning_rate_scheduler.step()

                train_loss += loss.item()
            if idx > (proportion * len(training_loader03)):
                break
        for idx, data in enumerate(training_loader00):
            ids = data['input_ids'].to(device, dtype=torch.long)
            mask = data['attention_mask'].to(device, dtype=torch.long)
            pos = data['pos'].reshape(-1).type(torch.LongTensor).to(device)

            optimizer.zero_grad()
            outputs1, outputs2 = model(ids, mask)

            pred2 = outputs2.reshape(-1, 44).to(device, dtype=torch.float32)

            with torch.enable_grad():
                loss = loss_fn(pred2, pos)

                loss.requires_grad_(True)
                print(f"train_loss: {loss.item()}")
                loss.backward()
                optimizer.step()
                learning_rate_scheduler.step()

                train_loss += loss.item()
            if idx > (proportion * len(training_loader00)):
                break

        print(f"---------- Epoch {epoch}: Training Stage End ----------")
        train_loss = train_loss / (proportion * ( len(training_loader03) + len(training_loader00) ))

        checkpoint = {
            'epoch': epoch,
            'avg_valid_loss': train_loss,
            'state_dict': model.state_dict(),
            'optimizer': optimizer.state_dict()
        }
        cm.save_model(checkpoint, checkpoint_path)
        print(f"---------- Epoch {epoch}: End ----------")
        model.eval()
    return model
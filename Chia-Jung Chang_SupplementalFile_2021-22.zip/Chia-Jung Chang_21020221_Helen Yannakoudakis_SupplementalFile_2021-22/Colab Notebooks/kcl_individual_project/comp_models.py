import torch
from transformers import BertModel
from transformers import RobertaModel
from torch.autograd import Variable

MAX_LEN = 256
device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

def load_model(checkpoint_path, model, optimizer):
    current_device='cpu'
    if torch.cuda.is_available():
      current_device=None
    checkpoint = torch.load(checkpoint_path, map_location=current_device)
    model.load_state_dict(checkpoint['state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer'])
    epoch = checkpoint['epoch']
    avg_valid_loss = checkpoint['avg_valid_loss']
    return model, optimizer, epoch, avg_valid_loss

def save_model(checkpoint, checkpoint_path):
    torch.save(checkpoint, checkpoint_path)

class ROBERTA_MRN_conll2003(torch.nn.Module):
    def __init__(self):
        super(ROBERTA_MRN_conll2003, self).__init__()
        self.bert_model = RobertaModel.from_pretrained("roberta-base")
        self.linear1 = torch.nn.Linear(self.bert_model.config.hidden_size, 47)
        self.linear2 = torch.nn.Linear(self.bert_model.config.hidden_size, 23)
        self.linear3 = torch.nn.Linear(self.bert_model.config.hidden_size, 9)
        self.dropout = torch.nn.Dropout(0.1)

        self.task_covariance = Variable(torch.eye(3)).cuda()
        self.class_covariance = Variable(torch.eye(79)).cuda()
        self.feature_covariance = Variable(torch.eye(self.bert_model.config.hidden_size)).cuda()

    def forward(self, input_ids, attention_mask):
        batch_size = input_ids.shape[0]
        embeddings = self.bert_model(input_ids, attention_mask=attention_mask)[0]

        # weights of linear layers
        W1_ini = self.linear1.weight
        W2_ini = self.linear2.weight
        W3_ini = self.linear3.weight

        logits1 = torch.zeros((batch_size, MAX_LEN, 47))
        logits2 = torch.zeros((batch_size, MAX_LEN, 23))
        logits3 = torch.zeros((batch_size, MAX_LEN, 9))

        for i in range(MAX_LEN):
            logit_t1 = self.dropout(self.linear1(embeddings[:, i, :]))
            logit_t2 = self.dropout(self.linear2(embeddings[:, i, :]))
            logit_t3 = self.dropout(self.linear3(embeddings[:, i, :]))
            logits1[:, i, :] = logit_t1
            logits2[:, i, :] = logit_t2
            logits3[:, i, :] = logit_t3

        return logits1, logits2, logits3, W1_ini, W2_ini, W3_ini

class ROBERTA_MRN_conll2000(torch.nn.Module):
    def __init__(self):
        super(ROBERTA_MRN_conll2000, self).__init__()
        self.bert_model = RobertaModel.from_pretrained("roberta-base")
        self.linear1 = torch.nn.Linear(self.bert_model.config.hidden_size, 44)
        self.linear2 = torch.nn.Linear(self.bert_model.config.hidden_size, 23)

        self.dropout = torch.nn.Dropout(0.1)

        self.task_covariance = Variable(torch.eye(2)).cuda()
        self.class_covariance = Variable(torch.eye(67)).cuda()
        self.feature_covariance = Variable(torch.eye(self.bert_model.config.hidden_size)).cuda()

    def forward(self, input_ids, attention_mask):
        batch_size = input_ids.shape[0]
        embeddings = self.bert_model(input_ids, attention_mask=attention_mask)[0]

        # weights of linear layers
        W1_ini = self.linear1.weight
        W2_ini = self.linear2.weight

        logits1 = torch.zeros((batch_size, MAX_LEN, 44))
        logits2 = torch.zeros((batch_size, MAX_LEN, 23))

        for i in range(MAX_LEN):
            logit_t1 = self.dropout(self.linear1(embeddings[:, i, :]))
            logit_t2 = self.dropout(self.linear2(embeddings[:, i, :]))
            logits1[:, i, :] = logit_t1
            logits2[:, i, :] = logit_t2

        return logits1, logits2, W1_ini, W2_ini


class ROBERTA_MTL_conll2003(torch.nn.Module):
    def __init__(self):
        super(ROBERTA_MTL_conll2003, self).__init__()
        self.bert_model = RobertaModel.from_pretrained("roberta-base")
        self.linear1 = torch.nn.Linear(self.bert_model.config.hidden_size, 47)
        self.linear2 = torch.nn.Linear(self.bert_model.config.hidden_size, 23)
        self.linear3 = torch.nn.Linear(self.bert_model.config.hidden_size, 9)
        self.dropout = torch.nn.Dropout(0.1)

    def forward(self, input_ids, attention_mask):
        batch_size = input_ids.shape[0]
        embeddings = self.bert_model(input_ids, attention_mask=attention_mask)[0]

        logits1 = torch.zeros((batch_size, MAX_LEN, 47))
        logits2 = torch.zeros((batch_size, MAX_LEN, 23))
        logits3 = torch.zeros((batch_size, MAX_LEN, 9))

        for i in range(MAX_LEN):
            logit_t1 = self.dropout(self.linear1(embeddings[:, i, :]))
            logit_t2 = self.dropout(self.linear2(embeddings[:, i, :]))
            logit_t3 = self.dropout(self.linear3(embeddings[:, i, :]))
            logits1[:, i, :] = logit_t1
            logits2[:, i, :] = logit_t2
            logits3[:, i, :] = logit_t3

        return logits1, logits2, logits3

class ROBERTA_MTL_conll2000(torch.nn.Module):
    def __init__(self):
        super(ROBERTA_MTL_conll2000, self).__init__()
        self.bert_model = RobertaModel.from_pretrained("roberta-base")
        self.linear1 = torch.nn.Linear(self.bert_model.config.hidden_size, 44)
        self.linear2 = torch.nn.Linear(self.bert_model.config.hidden_size, 23)
        self.dropout = torch.nn.Dropout(0.1)

    def forward(self, input_ids, attention_mask):
        batch_size = input_ids.shape[0]
        embeddings = self.bert_model(input_ids, attention_mask=attention_mask)[0]

        logits1 = torch.zeros((batch_size, MAX_LEN, 44))
        logits2 = torch.zeros((batch_size, MAX_LEN, 23))

        for i in range(MAX_LEN):
            logit_t1 = self.dropout(self.linear1(embeddings[:, i, :]))
            logit_t2 = self.dropout(self.linear2(embeddings[:, i, :]))
            logits1[:, i, :] = logit_t1
            logits2[:, i, :] = logit_t2

        return logits1, logits2

class ROBERTA_STL(torch.nn.Module):
    def __init__(self, num_labels):
        super(ROBERTA_STL, self).__init__()
        self.bert_model = RobertaModel.from_pretrained("roberta-base")
        self.linear = torch.nn.Linear(self.bert_model.config.hidden_size, num_labels)
        self.dropout = torch.nn.Dropout(0.1)
        self.n_labels = num_labels

    def forward(self, input_ids, attention_mask):
        batch_size = input_ids.shape[0]
        embeddings = self.bert_model(input_ids, attention_mask=attention_mask)[0]

        out = torch.zeros((batch_size, MAX_LEN, self.n_labels))

        for i in range(MAX_LEN):
            temp = self.dropout(self.linear(embeddings[:, i, :]))
            out[:, i, :] = temp

        return out

class BERT_MRN_conll2003(torch.nn.Module):
    def __init__(self):
        super(BERT_MRN_conll2003, self).__init__()
        self.bert_model = BertModel.from_pretrained("bert-base-cased")
        self.linear1 = torch.nn.Linear(self.bert_model.config.hidden_size, 47)
        self.linear2 = torch.nn.Linear(self.bert_model.config.hidden_size, 23)
        self.linear3 = torch.nn.Linear(self.bert_model.config.hidden_size, 9)
        self.dropout = torch.nn.Dropout(0.1)

        self.task_covariance = Variable(torch.eye(3)).cuda()
        self.class_covariance = Variable(torch.eye(79)).cuda()
        self.feature_covariance = Variable(torch.eye(self.bert_model.config.hidden_size)).cuda()

    def forward(self, input_ids, attention_mask):
        batch_size = input_ids.shape[0]
        embeddings = self.bert_model(input_ids, attention_mask=attention_mask)[0]

        # weights of linear layers
        W1_ini = self.linear1.weight
        W2_ini = self.linear2.weight
        W3_ini = self.linear3.weight

        logits1 = torch.zeros((batch_size, MAX_LEN, 47))
        logits2 = torch.zeros((batch_size, MAX_LEN, 23))
        logits3 = torch.zeros((batch_size, MAX_LEN, 9))

        for i in range(MAX_LEN):
            logit_t1 = self.dropout(self.linear1(embeddings[:, i, :]))
            logit_t2 = self.dropout(self.linear2(embeddings[:, i, :]))
            logit_t3 = self.dropout(self.linear3(embeddings[:, i, :]))
            logits1[:, i, :] = logit_t1
            logits2[:, i, :] = logit_t2
            logits3[:, i, :] = logit_t3

        return logits1, logits2, logits3, W1_ini, W2_ini, W3_ini

class BERT_MRN_conll2000(torch.nn.Module):
    def __init__(self):
        super(BERT_MRN_conll2000, self).__init__()
        self.bert_model = BertModel.from_pretrained("bert-base-cased")
        self.linear1 = torch.nn.Linear(self.bert_model.config.hidden_size, 44)
        self.linear2 = torch.nn.Linear(self.bert_model.config.hidden_size, 23)

        self.dropout = torch.nn.Dropout(0.1)

        self.task_covariance = Variable(torch.eye(2)).cuda()
        self.class_covariance = Variable(torch.eye(67)).cuda()
        self.feature_covariance = Variable(torch.eye(self.bert_model.config.hidden_size)).cuda()

    def forward(self, input_ids, attention_mask):
        batch_size = input_ids.shape[0]
        embeddings = self.bert_model(input_ids, attention_mask=attention_mask)[0]

        # weights of linear layers
        W1_ini = self.linear1.weight
        W2_ini = self.linear2.weight

        logits1 = torch.zeros((batch_size, MAX_LEN, 44))
        logits2 = torch.zeros((batch_size, MAX_LEN, 23))

        for i in range(MAX_LEN):
            logit_t1 = self.dropout(self.linear1(embeddings[:, i, :]))
            logit_t2 = self.dropout(self.linear2(embeddings[:, i, :]))
            logits1[:, i, :] = logit_t1
            logits2[:, i, :] = logit_t2

        return logits1, logits2, W1_ini, W2_ini

class BERT_MTL_conll2003(torch.nn.Module):
    def __init__(self):
        super(BERT_MTL_conll2003, self).__init__()
        self.bert_model = BertModel.from_pretrained("bert-base-cased")
        self.linear1 = torch.nn.Linear(self.bert_model.config.hidden_size, 47)
        self.linear2 = torch.nn.Linear(self.bert_model.config.hidden_size, 23)
        self.linear3 = torch.nn.Linear(self.bert_model.config.hidden_size, 9)
        self.dropout = torch.nn.Dropout(0.1)

    def forward(self, input_ids, attention_mask):
        batch_size = input_ids.shape[0]
        embeddings = self.bert_model(input_ids, attention_mask=attention_mask)[0]

        logits1 = torch.zeros((batch_size, MAX_LEN, 47))
        logits2 = torch.zeros((batch_size, MAX_LEN, 23))
        logits3 = torch.zeros((batch_size, MAX_LEN, 9))

        for i in range(MAX_LEN):
            logit_t1 = self.dropout(self.linear1(embeddings[:, i, :]))
            logit_t2 = self.dropout(self.linear2(embeddings[:, i, :]))
            logit_t3 = self.dropout(self.linear3(embeddings[:, i, :]))
            logits1[:, i, :] = logit_t1
            logits2[:, i, :] = logit_t2
            logits3[:, i, :] = logit_t3

        return logits1, logits2, logits3

class BERT_MTL_conll2000(torch.nn.Module):
    def __init__(self):
        super(BERT_MTL_conll2000, self).__init__()
        self.bert_model = BertModel.from_pretrained("bert-base-cased")
        self.linear1 = torch.nn.Linear(self.bert_model.config.hidden_size, 44)
        self.linear2 = torch.nn.Linear(self.bert_model.config.hidden_size, 23)
        self.dropout = torch.nn.Dropout(0.1)

    def forward(self, input_ids, attention_mask):
        batch_size = input_ids.shape[0]
        embeddings = self.bert_model(input_ids, attention_mask=attention_mask)[0]

        logits1 = torch.zeros((batch_size, MAX_LEN, 44))
        logits2 = torch.zeros((batch_size, MAX_LEN, 23))

        for i in range(MAX_LEN):
            logit_t1 = self.dropout(self.linear1(embeddings[:, i, :]))
            logit_t2 = self.dropout(self.linear2(embeddings[:, i, :]))
            logits1[:, i, :] = logit_t1
            logits2[:, i, :] = logit_t2

        return logits1, logits2

class BERT_STL(torch.nn.Module):
    def __init__(self, num_labels):
        super(BERT_STL, self).__init__()
        self.bert_model = BertModel.from_pretrained("bert-base-cased")
        self.linear = torch.nn.Linear(self.bert_model.config.hidden_size, num_labels)
        self.dropout = torch.nn.Dropout(0.1)
        self.n_labels = num_labels

    def forward(self, input_ids, attention_mask):
        batch_size = input_ids.shape[0]
        embeddings = self.bert_model(input_ids, attention_mask=attention_mask)[0]

        out = torch.zeros((batch_size, MAX_LEN, self.n_labels))

        for i in range(MAX_LEN):
            temp = self.dropout(self.linear(embeddings[:, i, :]))
            out[:, i, :] = temp

        return out

class BERT_MRN_BOTH_POS(torch.nn.Module):
    def __init__(self):
        super(BERT_MRN_BOTH_POS, self).__init__()
        self.bert_model = BertModel.from_pretrained("bert-base-cased")
        self.linear1 = torch.nn.Linear(self.bert_model.config.hidden_size, 47)
        self.linear2 = torch.nn.Linear(self.bert_model.config.hidden_size, 44)

        self.dropout = torch.nn.Dropout(0.1)

        self.task_covariance = Variable(torch.eye(2)).cuda()
        self.class_covariance = Variable(torch.eye(47)).cuda()
        self.feature_covariance = Variable(torch.eye(self.bert_model.config.hidden_size)).cuda()

    def forward(self, input_ids, attention_mask):
        batch_size = input_ids.shape[0]
        embeddings = self.bert_model(input_ids, attention_mask=attention_mask)[0]

        # weights of linear layers
        W1_ini = self.linear1.weight
        W2_ini = self.linear2.weight

        logits1 = torch.zeros((batch_size, MAX_LEN, 47))
        logits2 = torch.zeros((batch_size, MAX_LEN, 44))

        for i in range(MAX_LEN):
            logit_t1 = self.dropout(self.linear1(embeddings[:, i, :]))
            logit_t2 = self.dropout(self.linear2(embeddings[:, i, :]))
            logits1[:, i, :] = logit_t1
            logits2[:, i, :] = logit_t2

        return logits1, logits2, W1_ini, W2_ini

class BERT_MTL_BOTH_POS(torch.nn.Module):
    def __init__(self):
        super(BERT_MTL_BOTH_POS, self).__init__()
        self.bert_model = BertModel.from_pretrained("bert-base-cased")
        self.linear1 = torch.nn.Linear(self.bert_model.config.hidden_size, 47)
        self.linear2 = torch.nn.Linear(self.bert_model.config.hidden_size, 44)

        self.dropout = torch.nn.Dropout(0.1)

    def forward(self, input_ids, attention_mask):
        batch_size = input_ids.shape[0]
        embeddings = self.bert_model(input_ids, attention_mask=attention_mask)[0]

        logits1 = torch.zeros((batch_size, MAX_LEN, 47))
        logits2 = torch.zeros((batch_size, MAX_LEN, 44))

        for i in range(MAX_LEN):
            logit_t1 = self.dropout(self.linear1(embeddings[:, i, :]))
            logit_t2 = self.dropout(self.linear2(embeddings[:, i, :]))
            logits1[:, i, :] = logit_t1
            logits2[:, i, :] = logit_t2

        return logits1, logits2

class BERT_BiLSTM_MRN_conll2003(torch.nn.Module):
    def __init__(self):
        super(BERT_BiLSTM_MRN_conll2003, self).__init__()
        self.bert_model = BertModel.from_pretrained("bert-base-cased")
        self.bilstm = torch.nn.LSTM(self.bert_model.config.hidden_size, 768, num_layers=1, bidirectional=True,
                                    batch_first=True)
        self.linear1 = torch.nn.Linear(2*768, 47)
        self.linear2 = torch.nn.Linear(2*768, 23)
        self.linear3 = torch.nn.Linear(2*768, 9)
        self.dropout = torch.nn.Dropout(0.1)

        self.task_covariance = Variable(torch.eye(3)).cuda()
        self.class_covariance = Variable(torch.eye(79)).cuda()
        self.feature_covariance = Variable(torch.eye(2*768)).cuda()

    def forward(self, input_ids, attention_mask):
        batch_size = input_ids.shape[0]
        embeddings = self.bert_model(input_ids, attention_mask=attention_mask)[0]
        embeddings, _ = self.bilstm(embeddings)

        # weights of linear layers
        W1_ini = self.linear1.weight
        W2_ini = self.linear2.weight
        W3_ini = self.linear3.weight

        logits1 = torch.zeros((batch_size, MAX_LEN, 47))
        logits2 = torch.zeros((batch_size, MAX_LEN, 23))
        logits3 = torch.zeros((batch_size, MAX_LEN, 9))

        for i in range(MAX_LEN):
            logit_t1 = self.dropout(self.linear1(embeddings[:, i, :]))
            logit_t2 = self.dropout(self.linear2(embeddings[:, i, :]))
            logit_t3 = self.dropout(self.linear3(embeddings[:, i, :]))
            logits1[:, i, :] = logit_t1
            logits2[:, i, :] = logit_t2
            logits3[:, i, :] = logit_t3

        return logits1, logits2, logits3, W1_ini, W2_ini, W3_ini

class BERT_BiLSTM_MRN_conll2000(torch.nn.Module):
    def __init__(self):
        super(BERT_BiLSTM_MRN_conll2000, self).__init__()
        self.bert_model = BertModel.from_pretrained("bert-base-cased")
        self.bilstm = torch.nn.LSTM(self.bert_model.config.hidden_size, 768, num_layers=1, bidirectional=True,
                                    batch_first=True)
        self.linear1 = torch.nn.Linear(2 * 768, 44)
        self.linear2 = torch.nn.Linear(2 * 768, 23)

        self.dropout = torch.nn.Dropout(0.1)

        self.task_covariance = Variable(torch.eye(2)).cuda()
        self.class_covariance = Variable(torch.eye(67)).cuda()
        self.feature_covariance = Variable(torch.eye(2 * 768)).cuda()

    def forward(self, input_ids, attention_mask):
        batch_size = input_ids.shape[0]
        embeddings = self.bert_model(input_ids, attention_mask=attention_mask)[0]
        embeddings, _ = self.bilstm(embeddings)

        logits1 = self.dropout(self.linear1(embeddings).transpose(1, 2))
        logits2 = self.dropout(self.linear2(embeddings).transpose(1, 2))

        # weights of linear layers
        W1_ini = self.linear1.weight
        W2_ini = self.linear2.weight

        return logits1, logits2, W1_ini, W2_ini

class BERT_BiLSTM_MTL_conll2003(torch.nn.Module):
    def __init__(self):
        super(BERT_BiLSTM_MTL_conll2003, self).__init__()
        self.bert_model = BertModel.from_pretrained("bert-base-cased")
        self.bilstm = torch.nn.LSTM(self.bert_model.config.hidden_size, 768, num_layers=1, bidirectional=True,
                                    batch_first=True)
        self.linear1 = torch.nn.Linear(2 * 768, 47)
        self.linear2 = torch.nn.Linear(2 * 768, 23)
        self.linear3 = torch.nn.Linear(2 * 768, 9)
        self.dropout = torch.nn.Dropout(0.1)

    def forward(self, input_ids, attention_mask):
        batch_size = input_ids.shape[0]
        embeddings = self.bert_model(input_ids, attention_mask=attention_mask)[0]
        embeddings, _ = self.bilstm(embeddings)

        logits1 = self.dropout(self.linear1(embeddings).transpose(1, 2))
        logits2 = self.dropout(self.linear2(embeddings).transpose(1, 2))
        logits3 = self.dropout(self.linear3(embeddings).transpose(1, 2))

        return logits1, logits2, logits3

class BERT_BiLSTM_MTL_conll2000(torch.nn.Module):
    def __init__(self):
        super(BERT_BiLSTM_MTL_conll2000, self).__init__()
        self.bert_model = BertModel.from_pretrained("bert-base-cased")
        self.bilstm = torch.nn.LSTM(self.bert_model.config.hidden_size, 768, num_layers=1, bidirectional=True,
                                    batch_first=True)
        self.linear1 = torch.nn.Linear(2 * 768, 44)
        self.linear2 = torch.nn.Linear(2 * 768, 23)

        self.dropout = torch.nn.Dropout(0.1)

    def forward(self, input_ids, attention_mask):
        batch_size = input_ids.shape[0]
        embeddings = self.bert_model(input_ids, attention_mask=attention_mask)[0]
        embeddings, _ = self.bilstm(embeddings)

        logits1 = self.dropout(self.linear1(embeddings).transpose(1, 2))
        logits2 = self.dropout(self.linear2(embeddings).transpose(1, 2))

        return logits1, logits2
import torch
from seqeval.metrics import classification_report
from seqeval.metrics import accuracy_score
from seqeval.metrics import f1_score
from datasets import load_metric
import numpy as np

MAX_LEN = 256

device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

def compute_metrics(preds, labels, label_list):
    # delete -100 labels and then transform the predictions into corresponding labels
    true_labels = [[label_list[l] for l in label if l != -100] for label in labels]
    true_pred = [
        [label_list[p] for (p, l) in zip(pred, label) if l != -100]
        for pred, label in zip(preds, labels)
    ]
    return classification_report(true_labels, true_pred, digits=4)

def result_to_list(tar):
    res=[]
    for i in tar:
        for j in i:
            res.append(j)
    return np.asarray(res)

def test_conll2003_MRN_or_MTL(model, test_data_loader, datasets):
    label_list1 = datasets["train"].features["pos_tags"].feature.names
    label_list2 = datasets["train"].features["chunk_tags"].feature.names
    label_list3 = datasets["train"].features["ner_tags"].feature.names
    id2label1 = {str(i): label for i, label in enumerate(label_list1)}
    label2id1 = {v: k for k, v in id2label1.items()}
    id2label2 = {str(i): label for i, label in enumerate(label_list2)}
    label2id2 = {v: k for k, v in id2label2.items()}
    id2label3 = {str(i): label for i, label in enumerate(label_list3)}
    label2id3 = {v: k for k, v in id2label3.items()}
    true_labels1 = []
    pred_labels1 = []
    true_labels2 = []
    pred_labels2 = []
    true_labels3 = []
    pred_labels3 = []

    model.eval()
    with torch.no_grad():
        for idx, data in enumerate(test_data_loader):
            ids = data['input_ids'].to(device, dtype=torch.long)
            mask = data['attention_mask'].to(device, dtype=torch.long)
            pos = data['pos'].type(torch.IntTensor).to(device)
            chunk = data['chunk'].type(torch.IntTensor).to(device)
            ner = data['ner'].type(torch.IntTensor).to(device)

            outputs1, outputs2, outputs3, *_ = model(ids, mask)
            pred1 = torch.argmax(torch.softmax(outputs1, dim=2), dim=-1).to(device, dtype=torch.int8)
            pred2 = torch.argmax(torch.softmax(outputs2, dim=2), dim=-1).to(device, dtype=torch.int8)
            pred3 = torch.argmax(torch.softmax(outputs3, dim=2), dim=-1).to(device, dtype=torch.int8)

            true_labels1.append(pos.cpu().detach().numpy().tolist())
            true_labels2.append(chunk.cpu().detach().numpy().tolist())
            true_labels3.append(ner.cpu().detach().numpy().tolist())
            pred_labels1.append(pred1.cpu().detach().numpy().tolist())
            pred_labels2.append(pred2.cpu().detach().numpy().tolist())
            pred_labels3.append(pred3.cpu().detach().numpy().tolist())
    t1 = result_to_list(true_labels1)
    t2 = result_to_list(true_labels2)
    t3 = result_to_list(true_labels3)
    p1 = result_to_list(pred_labels1)
    p2 = result_to_list(pred_labels2)
    p3 = result_to_list(pred_labels3)
    print(compute_metrics(p1, t1, label_list1))
    print(compute_metrics(p2, t2, label_list2))
    print(compute_metrics(p3, t3, label_list3))

def test_conll2000_MRN_or_MTL(model, test_data_loader, datasets):
    label_list1 = datasets["train"].features["pos_tags"].feature.names
    label_list2 = datasets["train"].features["chunk_tags"].feature.names
    id2label1 = {str(i): label for i, label in enumerate(label_list1)}
    label2id1 = {v: k for k, v in id2label1.items()}
    id2label2 = {str(i): label for i, label in enumerate(label_list2)}
    label2id2 = {v: k for k, v in id2label2.items()}
    true_labels1 = []
    pred_labels1 = []
    true_labels2 = []
    pred_labels2 = []
    model.eval()
    with torch.no_grad():
        for idx, data in enumerate(test_data_loader):
            ids = data['input_ids'].to(device, dtype=torch.long)
            mask = data['attention_mask'].to(device, dtype=torch.long)
            pos = data['pos'].type(torch.IntTensor).to(device)
            chunk = data['chunk'].type(torch.IntTensor).to(device)

            outputs1, outputs2, *_ = model(ids, mask)
            pred1 = torch.argmax(torch.softmax(outputs1, dim=2), dim=-1).to(device, dtype=torch.int8)
            pred2 = torch.argmax(torch.softmax(outputs2, dim=2), dim=-1).to(device, dtype=torch.int8)

            true_labels1.append(pos.cpu().detach().numpy().tolist())
            true_labels2.append(chunk.cpu().detach().numpy().tolist())
            pred_labels1.append(pred1.cpu().detach().numpy().tolist())
            pred_labels2.append(pred2.cpu().detach().numpy().tolist())
    t1 = result_to_list(true_labels1)
    t2 = result_to_list(true_labels2)
    p1 = result_to_list(pred_labels1)
    p2 = result_to_list(pred_labels2)
    print(compute_metrics(p1, t1, label_list1))
    print(compute_metrics(p2, t2, label_list2))

def test_STL(model, test_data_loader, datasets, task):
    label_list = datasets["train"].features[f"{task}_tags"].feature.names
    id2label = {str(i): label for i, label in enumerate(label_list)}
    label2id = {v: k for k, v in id2label.items()}
    true_labels = []
    pred_labels = []

    model.eval()
    with torch.no_grad():
        for idx, data in enumerate(test_data_loader):
            ids = data['input_ids'].to(device, dtype=torch.long)
            mask = data['attention_mask'].to(device, dtype=torch.long)
            TASK = data[f"{task}"].type(torch.IntTensor).to(device)

            out = model(ids, mask)
            pred = torch.argmax(torch.softmax(out, dim=2), dim=-1).to(device, dtype=torch.int8)

            true_labels.append(TASK.cpu().detach().numpy().tolist())
            pred_labels.append(pred.cpu().detach().numpy().tolist())
    t = result_to_list(true_labels)
    p = result_to_list(pred_labels)
    print(compute_metrics(p,t,label_list))

def test_both_pos_MRN_or_MTL(model, test_data_loader03, datasets03, test_data_loader00, datasets00):
    label_list1 = datasets03["train"].features["pos_tags"].feature.names
    label_list2 = datasets00["train"].features["pos_tags"].feature.names
    id2label1 = {str(i): label for i, label in enumerate(label_list1)}
    label2id1 = {v: k for k, v in id2label1.items()}
    id2label2 = {str(i): label for i, label in enumerate(label_list2)}
    label2id2 = {v: k for k, v in id2label2.items()}
    true_labels1 = []
    pred_labels1 = []
    true_labels2 = []
    pred_labels2 = []
    model.eval()
    with torch.no_grad():
        for idx, data in enumerate(test_data_loader03):
            ids = data['input_ids'].to(device, dtype=torch.long)
            mask = data['attention_mask'].to(device, dtype=torch.long)
            pos = data['pos'].type(torch.IntTensor).to(device)

            outputs1, outputs2, *_ = model(ids, mask)
            pred1 = torch.argmax(torch.softmax(outputs1, dim=2), dim=-1).to(device, dtype=torch.int8)

            true_labels1.append(pos.cpu().detach().numpy().tolist())
            pred_labels1.append(pred1.cpu().detach().numpy().tolist())
        for idx, data in enumerate(test_data_loader00):
            ids = data['input_ids'].to(device, dtype=torch.long)
            mask = data['attention_mask'].to(device, dtype=torch.long)
            pos = data['pos'].type(torch.IntTensor).to(device)

            outputs1, outputs2, *_ = model(ids, mask)
            pred2 = torch.argmax(torch.softmax(outputs2, dim=2), dim=-1).to(device, dtype=torch.int8)

            true_labels2.append(pos.cpu().detach().numpy().tolist())
            pred_labels2.append(pred2.cpu().detach().numpy().tolist())
    t1 = result_to_list(true_labels1)
    t2 = result_to_list(true_labels2)
    p1 = result_to_list(pred_labels1)
    p2 = result_to_list(pred_labels2)
    print(compute_metrics(p1, t1, label_list1))
    print(compute_metrics(p2, t2, label_list2))
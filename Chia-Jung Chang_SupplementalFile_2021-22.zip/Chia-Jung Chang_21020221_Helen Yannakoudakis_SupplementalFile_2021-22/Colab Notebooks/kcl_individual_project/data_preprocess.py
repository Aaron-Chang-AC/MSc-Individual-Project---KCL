import torch
import torch.nn as nn
import pandas as pd
import numpy as np
import shutil
import sys
from datasets import load_dataset, load_metric
import truecase
import re
import nltk
nltk.download('punkt')


class CoNLL_03(torch.utils.data.Dataset):
    def __init__(self, df, tokenizer, max_len):
        self.tokenizer = tokenizer
        self.df = df
        self.input_ids = df['input_ids']
        self.attention_mask = df['attention_mask']
        self.pos = df['pos']
        self.chunk = df['chunk']
        self.ner = df['ner']
        self.max_len = max_len

    def __len__(self):
        return len(self.input_ids)

    def __getitem__(self, index):
        if index >= len(self): raise IndexError

        return {
            'input_ids': torch.cat((torch.FloatTensor(self.input_ids[index]), torch.zeros(self.max_len - len(self.input_ids[index])))),
            'attention_mask': torch.cat((torch.FloatTensor(self.attention_mask[index]), torch.zeros(self.max_len - len(self.attention_mask[index])))),
            'token_type_ids': torch.zeros(self.max_len),
            'pos': torch.FloatTensor(torch.cat((torch.FloatTensor(self.pos[index]), torch.zeros(self.max_len - len(self.pos[index])) - 100))),
            'chunk': torch.FloatTensor(torch.cat((torch.FloatTensor(self.chunk[index]), torch.zeros(self.max_len - len(self.chunk[index])) - 100))),
            'ner': torch.FloatTensor(torch.cat((torch.FloatTensor(self.ner[index]), torch.zeros(self.max_len - len(self.ner[index])) - 100)))
        }

class CoNLL_00(torch.utils.data.Dataset):
    def __init__(self, df, tokenizer, max_len):
        self.tokenizer = tokenizer
        self.df = df
        self.input_ids = df['input_ids']
        self.attention_mask = df['attention_mask']
        self.pos = df['pos']
        self.chunk = df['chunk']
        self.max_len = max_len

    def __len__(self):
        return len(self.input_ids)

    def __getitem__(self, index):
        if index >= len(self): raise IndexError

        return {
            'input_ids': torch.cat((torch.FloatTensor(self.input_ids[index]), torch.zeros(self.max_len - len(self.input_ids[index])))),
            'attention_mask': torch.cat((torch.FloatTensor(self.attention_mask[index]), torch.zeros(self.max_len - len(self.attention_mask[index])))),
            'token_type_ids': torch.zeros(self.max_len),
            'pos': torch.FloatTensor(torch.cat((torch.FloatTensor(self.pos[index]), torch.zeros(self.max_len - len(self.pos[index])) - 100))),
            'chunk': torch.FloatTensor(torch.cat((torch.FloatTensor(self.chunk[index]), torch.zeros(self.max_len - len(self.chunk[index])) - 100)))
        }

def load_conll(target):
    if target == "conll2003":
        d = load_dataset("conll2003")
        return d
    else:
        d = load_dataset("conll2000")
        return d

def truecase_tokens(tokens):
    w_list = [(w, i) for i, w in enumerate(tokens) if all(c.isalpha() for c in w)]
    L = [w for w, _ in w_list if re.match(r'\b[A-Z\.\-]+\b', w)]
    if len(L) and len(L) == len(w_list):
        P = truecase.get_true_case(' '.join(L)).split()
        if len(P) != len(w_list):
            return tokens
        for (w, i), n in zip(w_list, P):
            tokens[i] = n
    return tokens

def tokenization_with_alignment(tokenizer, input_tokens, raw_labels, task_name):
    output_tokens = tokenizer(input_tokens['tokens'].tolist(), truncation=True, is_split_into_words=True)
    total_labels = []
    for i, label in enumerate(raw_labels[f"{task_name}_tags"]):
        idices = output_tokens.word_ids(batch_index=i)
        prev_idx = None
        label_idices = []
        for idx in idices:
            if idx is None:
                label_idices.append(-100)
            elif idx != prev_idx:
                label_idices.append(label[idx])
            else:
                label_idices.append(-100)
            prev_idx = idx
        total_labels.append(label_idices)
    output_tokens["labels"] = total_labels
    return output_tokens

def preprocess_raw_dataset(tokenizer, dataset_name, datasets, BATCH_SIZE=16, MAX_LEN=256):
    task1 = "pos"
    task2 = "chunk"
    task3 = "ner"
    train_tokens_df = pd.DataFrame()
    validation_tokens_df = pd.DataFrame()
    test_tokens_df = pd.DataFrame()

    train_tokens_df['tokens'] = datasets['train']['tokens']
    test_tokens_df['tokens'] = datasets['test']['tokens']

    train_tokens_df['tokens'] = train_tokens_df['tokens'].apply(lambda x: truecase_tokens(x))
    test_tokens_df['tokens'] = test_tokens_df['tokens'].apply(lambda x: truecase_tokens(x))

    training_dataset1 = tokenization_with_alignment(tokenizer, train_tokens_df, datasets['train'], task1)
    training_dataset2 = tokenization_with_alignment(tokenizer, train_tokens_df, datasets['train'], task2)


    training_dataset = pd.DataFrame()
    training_dataset['input_ids'] = training_dataset1['input_ids']
    training_dataset['attention_mask'] = training_dataset1['attention_mask']
    training_dataset['pos'] = training_dataset1['labels']
    training_dataset['chunk'] = training_dataset2['labels']

    testing_dataset1 = tokenization_with_alignment(tokenizer, test_tokens_df, datasets['test'], task1)
    testing_dataset2 = tokenization_with_alignment(tokenizer, test_tokens_df, datasets['test'], task2)

    testing_dataset = pd.DataFrame()
    testing_dataset['input_ids'] = testing_dataset1['input_ids']
    testing_dataset['attention_mask'] = testing_dataset1['attention_mask']
    testing_dataset['pos'] = testing_dataset1['labels']
    testing_dataset['chunk'] = testing_dataset2['labels']

    if dataset_name == "conll2003":
        validation_tokens_df['tokens'] = datasets['validation']['tokens']
        validation_tokens_df['tokens'] = validation_tokens_df['tokens'].apply(lambda x: truecase_tokens(x))

        validation_dataset1 = tokenization_with_alignment(tokenizer, validation_tokens_df, datasets['validation'], task1)
        validation_dataset2 = tokenization_with_alignment(tokenizer, validation_tokens_df, datasets['validation'], task2)
        validation_dataset3 = tokenization_with_alignment(tokenizer, validation_tokens_df, datasets['validation'], task3)

        validation_dataset = pd.DataFrame()
        validation_dataset['input_ids'] = validation_dataset1['input_ids']
        validation_dataset['attention_mask'] = validation_dataset1['attention_mask']
        validation_dataset['pos'] = validation_dataset1['labels']
        validation_dataset['chunk'] = validation_dataset2['labels']
        validation_dataset['ner'] = validation_dataset3['labels']

        training_dataset3 = tokenization_with_alignment(tokenizer, train_tokens_df, datasets['train'], task3)
        training_dataset['ner'] = training_dataset3['labels']

        testing_dataset3 = tokenization_with_alignment(tokenizer, test_tokens_df, datasets['test'], task3)
        testing_dataset['ner'] = testing_dataset3['labels']

        train_dataset = CoNLL_03(training_dataset, tokenizer, MAX_LEN)
        valid_dataset = CoNLL_03(validation_dataset, tokenizer, MAX_LEN)
        test_dataset = CoNLL_03(testing_dataset, tokenizer, MAX_LEN)

        train_data_loader = torch.utils.data.DataLoader(
            train_dataset,
            batch_size=BATCH_SIZE,
            shuffle=True,
            num_workers=0
        )

        val_data_loader = torch.utils.data.DataLoader(
            valid_dataset,
            batch_size=BATCH_SIZE,
            shuffle=False,
            num_workers=0
        )

        test_data_loader = torch.utils.data.DataLoader(
            test_dataset,
            batch_size=BATCH_SIZE,
            shuffle=False,
            num_workers=0
        )
        return train_data_loader, val_data_loader, test_data_loader
    else:
        train_dataset = CoNLL_00(training_dataset, tokenizer, MAX_LEN)
        test_dataset = CoNLL_00(testing_dataset, tokenizer, MAX_LEN)
        train_data_loader = torch.utils.data.DataLoader(
            train_dataset,
            batch_size=BATCH_SIZE,
            shuffle=True,
            num_workers=0
        )
        test_data_loader = torch.utils.data.DataLoader(
            test_dataset,
            batch_size=BATCH_SIZE,
            shuffle=False,
            num_workers=0
        )
        return train_data_loader, test_data_loader


    